function enviar(){
    let marca = document.getElementById('marca').value;
    let cor = document.getElementById('cor').value; 
    let modelo = document.getElementById('modelo').value;

    const obj = {
        marca: marca, cor: cor, modelo: modelo
    };

    localStorage.setItem("cadastro do carro", JSON.stringify(obj)); 
    alert('A marca do carro é: '+obj.marca+', a cor do carro é: '+obj.cor+', e o modelo do carro é: '+obj.modelo)  
}